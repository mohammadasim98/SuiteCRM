<?php
// created: 2021-07-31 12:56:41
$dictionary["sp_Retailer"]["fields"]["sp_retailer_sp_supplier"] = array (
  'name' => 'sp_retailer_sp_supplier',
  'type' => 'link',
  'relationship' => 'sp_retailer_sp_supplier',
  'source' => 'non-db',
  'module' => 'sp_Supplier',
  'bean_name' => false,
  'vname' => 'LBL_SP_RETAILER_SP_SUPPLIER_FROM_SP_SUPPLIER_TITLE',
);
