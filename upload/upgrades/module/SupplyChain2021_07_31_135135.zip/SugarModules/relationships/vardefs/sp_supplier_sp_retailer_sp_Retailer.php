<?php
// created: 2021-07-31 13:51:35
$dictionary["sp_Retailer"]["fields"]["sp_supplier_sp_retailer"] = array (
  'name' => 'sp_supplier_sp_retailer',
  'type' => 'link',
  'relationship' => 'sp_supplier_sp_retailer',
  'source' => 'non-db',
  'module' => 'sp_Supplier',
  'bean_name' => 'sp_Supplier',
  'vname' => 'LBL_SP_SUPPLIER_SP_RETAILER_FROM_SP_SUPPLIER_TITLE',
);
