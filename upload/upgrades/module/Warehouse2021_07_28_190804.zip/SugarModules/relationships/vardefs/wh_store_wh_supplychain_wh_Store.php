<?php
// created: 2021-07-28 19:08:04
$dictionary["wh_Store"]["fields"]["wh_store_wh_supplychain"] = array (
  'name' => 'wh_store_wh_supplychain',
  'type' => 'link',
  'relationship' => 'wh_store_wh_supplychain',
  'source' => 'non-db',
  'module' => 'wh_SupplyChain',
  'bean_name' => 'wh_SupplyChain',
  'side' => 'right',
  'vname' => 'LBL_WH_STORE_WH_SUPPLYCHAIN_FROM_WH_SUPPLYCHAIN_TITLE',
);
