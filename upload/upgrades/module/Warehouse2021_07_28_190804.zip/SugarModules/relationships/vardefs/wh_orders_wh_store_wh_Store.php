<?php
// created: 2021-07-28 19:08:04
$dictionary["wh_Store"]["fields"]["wh_orders_wh_store"] = array (
  'name' => 'wh_orders_wh_store',
  'type' => 'link',
  'relationship' => 'wh_orders_wh_store',
  'source' => 'non-db',
  'module' => 'wh_Orders',
  'bean_name' => 'wh_Orders',
  'side' => 'right',
  'vname' => 'LBL_WH_ORDERS_WH_STORE_FROM_WH_ORDERS_TITLE',
);
