<?php
// created: 2021-07-28 19:08:04
$dictionary["wh_Retailers"]["fields"]["wh_orders_wh_retailers"] = array (
  'name' => 'wh_orders_wh_retailers',
  'type' => 'link',
  'relationship' => 'wh_orders_wh_retailers',
  'source' => 'non-db',
  'module' => 'wh_Orders',
  'bean_name' => 'wh_Orders',
  'side' => 'right',
  'vname' => 'LBL_WH_ORDERS_WH_RETAILERS_FROM_WH_ORDERS_TITLE',
);
