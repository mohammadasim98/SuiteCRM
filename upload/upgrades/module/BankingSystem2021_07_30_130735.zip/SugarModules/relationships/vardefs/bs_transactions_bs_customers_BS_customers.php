<?php
// created: 2021-07-30 13:07:35
$dictionary["BS_customers"]["fields"]["bs_transactions_bs_customers"] = array (
  'name' => 'bs_transactions_bs_customers',
  'type' => 'link',
  'relationship' => 'bs_transactions_bs_customers',
  'source' => 'non-db',
  'module' => 'BS_transactions',
  'bean_name' => 'BS_transactions',
  'side' => 'right',
  'vname' => 'LBL_BS_TRANSACTIONS_BS_CUSTOMERS_FROM_BS_TRANSACTIONS_TITLE',
);
